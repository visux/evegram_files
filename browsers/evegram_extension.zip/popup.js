document.getElementById("openSite").addEventListener("click", () => {
  chrome.tabs.create({ url: "https://web.evegram.eu" });
});
